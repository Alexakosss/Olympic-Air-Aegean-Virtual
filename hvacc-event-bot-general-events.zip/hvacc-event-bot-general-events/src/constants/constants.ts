// HvACC thumbnail for embeds
export const HVACC_DEFAULT_THUMBNAIL =
  "https://hvacc.org/uploads/monthly_2023_09/hvacc-logo-1-1.png.0a10fff963392770e511875615edaccc.png?format=webp&quality=lossless";

// HvACC footer logo for embeds
export const HVACC_FOOTER_LOGO = "https://i.ibb.co/vxR9hkdC/image.png";

// Vatsim Data API
export const VATSIM_DATA_API = "https://data.vatsim.net/v3/vatsim-data.json";

export const MONITOR_CHANNEL_NAMES = ["General"];

export const SYMBOLS = {
  DataService: Symbol.for("DataService"),
  PositionsMap: Symbol.for("PositionsMap"),
  EnvConfig: Symbol.for("EnvConfig"),
  Logger: Symbol.for("Logger"),
  Client: Symbol.for("Client"),
};
